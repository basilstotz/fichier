# Defaults for fichier initscript
# sourced by /etc/init.d/fichier
# installed at /etc/default/fichier by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
